﻿using Facturacion_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace Facturacion_MVC.Controllers
{
    public class TBLproductoController : Controller
    {
        // GET: TBLproducto
        public ActionResult Index()
        {
            BDFacturacion db = new BDFacturacion();
            var productos = db.TBLPRODUCTO.ToList();
            return View(productos);
        }

        public ActionResult Nuevo()
        {
            BDFacturacion db = new BDFacturacion();
            ViewBag.IdCategoria = new SelectList(db.TBLCATEGORIA_PROD, "IdCategoria", "StrDescripcion");
            return View();
        }

        [HttpPost]
        public ActionResult Nuevo(FormCollection collection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BDFacturacion db = new BDFacturacion();
                    var nuevoProducto = new TBLPRODUCTO();
                    nuevoProducto.StrNombre = collection["StrNombre"];
                    nuevoProducto.StrCodigo = collection["StrCodigo"];
                    nuevoProducto.NumPrecioCompra = Convert.ToDouble(collection["NumPrecioCompra"]);
                    nuevoProducto.NumPrecioVenta = Convert.ToDouble(collection["NumPrecioVenta"]);
                    nuevoProducto.IdCategoria = int.Parse(collection["IdCategoria"]);
                    nuevoProducto.StrDetalle = collection["StrDetalle"];
                    nuevoProducto.strFoto = collection["strFoto"];
                    nuevoProducto.NumStock = int.Parse(collection["NumStock"]);
                    nuevoProducto.DtmFechaModifica = DateTime.Now;
                    nuevoProducto.StrUsuarioModifica = "Admin";

                    db.TBLPRODUCTO.Add(nuevoProducto);
                    db.SaveChanges();

                    return Redirect("/TBLproducto/index");
                }

                return View(collection);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public ActionResult Editar(int id)
        {
            BDFacturacion db = new BDFacturacion();
            var producto = db.TBLPRODUCTO.Find(id);
            ViewBag.IdCategoria = new SelectList(db.TBLCATEGORIA_PROD, "IdCategoria", "StrDescripcion", producto.IdCategoria);
            return View(producto);
        }

        [HttpPost]
        public ActionResult Editar(TBLPRODUCTO model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (BDFacturacion db = new BDFacturacion())
                    {
                        var productoMod = db.TBLPRODUCTO.Find(model.IdProducto);
                        productoMod.StrNombre = model.StrNombre;
                        productoMod.StrCodigo = model.StrCodigo;
                        productoMod.NumPrecioCompra = model.NumPrecioCompra;
                        productoMod.NumPrecioVenta = model.NumPrecioVenta;
                        productoMod.IdCategoria = model.IdCategoria;
                        productoMod.StrDetalle = model.StrDetalle;
                        productoMod.strFoto = model.strFoto;
                        productoMod.NumStock = model.NumStock;
                        productoMod.DtmFechaModifica = DateTime.Now;
                        productoMod.StrUsuarioModifica = "javier";

                        db.Entry(productoMod).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }

                    return Redirect("/TBLproducto/index");
                }

                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet]
        public ActionResult Borrar(int id)
        {
            try
            {
                using (BDFacturacion db = new BDFacturacion())
                {
                    var producto = db.TBLPRODUCTO.Find(id);
                    db.TBLPRODUCTO.Remove(producto);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return Redirect("/TBLproducto/index");
        }
    }
}
