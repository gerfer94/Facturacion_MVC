﻿using Facturacion_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Facturacion_MVC.Controllers
{
    public class TBLclientesController : Controller
    {
        // GET: TBLclientes
        public ActionResult Index()
        {
            BDFacturacion db = new BDFacturacion();
            var clientes = db.TBLCLIENTES;
            return View(clientes.ToList());
        }

        public ActionResult Nuevo()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Nuevo(FormCollection collection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BDFacturacion db = new BDFacturacion();
                    var nuevoCliente = new TBLCLIENTES();
                    nuevoCliente.StrNombre = collection["StrNombre"];
                    nuevoCliente.NumDocumento = long.Parse(collection["NumDocumento"]);
                    nuevoCliente.StrDireccion = collection["StrDireccion"];
                    nuevoCliente.StrTelefono = collection["StrTelefono"];
                    nuevoCliente.StrEmail = collection["StrEmail"];
                    nuevoCliente.DtmFechaModifica = DateTime.Now.Date;
                    nuevoCliente.StrUsuarioModifica = "Admin";
                    db.TBLCLIENTES.Add(nuevoCliente);
                    db.SaveChanges();
                    return Redirect("/TBLclientes/index");
                }
                return View(collection);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public ActionResult Editar(int id)
        {
            BDFacturacion db = new BDFacturacion();
            var cliente = db.TBLCLIENTES.Find(id);
            return View(cliente);
        }

        [HttpPost]
        public ActionResult Editar(TBLCLIENTES model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (BDFacturacion db = new BDFacturacion())
                    {
                        var clienteMod = db.TBLCLIENTES.Find(model.IdCliente);
                        clienteMod.StrNombre = model.StrNombre;
                        clienteMod.NumDocumento = model.NumDocumento;
                        clienteMod.StrDireccion = model.StrDireccion;
                        clienteMod.StrTelefono = model.StrTelefono;
                        clienteMod.StrEmail = model.StrEmail;
                        clienteMod.DtmFechaModifica = DateTime.Now.Date;
                        clienteMod.StrUsuarioModifica = "javier";
                        db.Entry(clienteMod).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                    }
                    return Redirect("/TBLclientes/index");
                }
                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [HttpGet]
        public ActionResult Borrar(int id)
        {
            try
            {
                using (BDFacturacion db = new BDFacturacion())
                {
                    var cliente = db.TBLCLIENTES.Find(id);
                    db.TBLCLIENTES.Remove(cliente);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return Redirect("/TBLclientes/index");
        }
    }
}
